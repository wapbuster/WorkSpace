package com.indus.training.orm.exception;

public class IndusException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -381251771806252569L;

	public IndusException() {
		// TODO Auto-generated constructor stub
	}

	public IndusException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public IndusException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public IndusException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public IndusException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
