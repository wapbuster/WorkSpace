package com.indus.training.domain;

public class CalciOutput {

	private double param1;

	private double param2;

	private double result;

	public double getParam1() {
		return param1;
	}

	public void setParam1(double parameter1) {
		param1 = parameter1;
	}

	public double getParam2() {
		return param2;
	}

	public void setParam2(double parameter2) {
		param2 = parameter2;
	}

	public double getResult() {
		return result;
	}

	public void setResult(double response) {
		result = response;
	}

}
