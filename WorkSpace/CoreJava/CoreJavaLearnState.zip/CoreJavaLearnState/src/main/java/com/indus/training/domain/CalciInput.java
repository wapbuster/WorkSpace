package com.indus.training.domain;

public class CalciInput {

	private double param1;

	private double param2;

	public double getParam1() {
		return param1;
	}

	public void setParam1(double parameter1) {
		param1 = parameter1;
	}

	public double getParam2() {
		return param2;
	}

	public void setParam2(double parameter2) {
		param2 = parameter2;
	}

}
