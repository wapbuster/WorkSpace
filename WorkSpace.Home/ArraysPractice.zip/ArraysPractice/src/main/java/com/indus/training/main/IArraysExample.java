package com.indus.training.main;

public interface IArraysExample {
	
	//public double add(double[] args);
	//public double add(double ... args);
public double add(double[][] array1, double[][] array2);
}
