package com.indus.training.body.impl;

import com.indus.training.body.IBody;

public class HondaCivicBoby implements IBody {

	public void carBodyDetails() throws Exception {
		System.out.println("Honda Civic V6 Exl Body");
	}

}
