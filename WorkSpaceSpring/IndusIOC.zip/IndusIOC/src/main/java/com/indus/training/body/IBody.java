package com.indus.training.body;

public interface IBody {
	
	public void carBodyDetails()throws Exception;

}
