package com.indus.training.tyre.impl;

import com.indus.training.tyre.ITyre;

public class MRFTyre implements ITyre {

	public void rotate() throws Exception {
		System.out.println("MRF tyre Rotates");
	}

	public void tyreDetails() throws Exception {
		System.out.println("MRF tyre 50/50 250 345 details");

	}

}
