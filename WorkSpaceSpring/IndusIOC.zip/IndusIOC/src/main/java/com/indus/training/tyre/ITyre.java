package com.indus.training.tyre;

public interface ITyre {
	
	public void rotate()throws Exception;
	
	public void tyreDetails() throws Exception;

}
