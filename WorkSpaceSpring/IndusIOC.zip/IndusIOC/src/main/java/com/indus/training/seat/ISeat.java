package com.indus.training.seat;

public interface ISeat {
	
	public void seatDetails() throws Exception;

}
