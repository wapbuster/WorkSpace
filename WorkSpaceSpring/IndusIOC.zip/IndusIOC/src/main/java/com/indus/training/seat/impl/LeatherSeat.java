package com.indus.training.seat.impl;

import com.indus.training.seat.ISeat;

public class LeatherSeat implements ISeat {

	public void seatDetails() throws Exception {
		System.out.println("Leather seat , buket style etc...");
	}

}
